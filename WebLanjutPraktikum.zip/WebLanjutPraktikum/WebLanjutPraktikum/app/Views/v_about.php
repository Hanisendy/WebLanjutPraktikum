<div class="container mt-3">
    <div class="text-center">
        <img src="/assets/images/linux.png" alt="logo" width="180" class="img-thumbnail rounded-circle">
        <h1 class="display-4">Praktikum Web Lanjut Dengan Studi Kasus Blog App</h1>
        <p class="lead">Programming | Codeigniter 4 | Php</p>
    </div>
</div>