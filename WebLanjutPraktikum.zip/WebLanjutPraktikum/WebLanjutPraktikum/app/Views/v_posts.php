<div class="container mt-3">
    <div class="text-center">
        <h1>All Posts</h1>
    </div>
</div>